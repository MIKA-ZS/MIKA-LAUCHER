# MIKA ZS LAUCHER

Launcher Android định hướng **FCL-based**, với UI Material 3 và logo mèo do người dùng cung cấp.

## Đã dựng
- UI dark hiện đại
- Logo MIKA ZS
- Hồ sơ/instance
- Mods/Shaders/Resource Packs/Modpacks
- Modrinth UI
- Java/RAM/JVM
- Renderer manager
- Accounts
- Logs / Crash Analyzer
- Kiến trúc để nối FCL launcher core

## Phần cần nối với FCL thật
Bản này là UI/source foundation, không đóng gói Minecraft hay FCL proprietary/runtime vào project.
Cần tích hợp source/engine FCL tương ứng và tuân thủ GPL-3.0 của FCL khi phân phối bản fork.

Tên hiển thị chính thức: MIKA ZS LAUCHER

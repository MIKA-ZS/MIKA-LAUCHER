package com.mikazs.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*

enum class Screen(val label: String) {
    HOME("Trang chủ"), INSTANCES("Hồ sơ"), MODS("Mods"), SHADERS("Shaders"),
    PACKS("Resource Packs"), MODPACKS("Modpacks"), MODRINTH("Modrinth"),
    JAVA("Java / JVM"), RENDERER("Renderer"), ACCOUNTS("Tài khoản"), LOGS("Nhật ký"),
    SETTINGS("Cài đặt")
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedInstance by remember { mutableStateOf("1.21.11 Fabric") }
    var ram by remember { mutableFloatStateOf(2048f) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        NavigationSuiteScaffold(
            navigationSuiteItems = {
                listOf(Screen.HOME, Screen.INSTANCES, Screen.MODS, Screen.MODRINTH,
                    Screen.JAVA, Screen.RENDERER, Screen.ACCOUNTS, Screen.LOGS, Screen.SETTINGS)
                    .forEach { item ->
                        item(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = { Icon(iconFor(item), null) },
                            label = { Text(item.label) }
                        )
                    }
            }
        ) {
            when (screen) {
                Screen.HOME -> Home(selectedInstance, ram, onPlay = { /* FCL launch bridge */ })
                Screen.INSTANCES -> Instances(selectedInstance) { selectedInstance = it }
                Screen.MODS -> Manager("Mods", "Quét, bật/tắt, dependency và kiểm tra tương thích.")
                Screen.SHADERS -> Manager("Shaders", "Bật/tắt shader và kiểm tra renderer.")
                Screen.PACKS -> Manager("Resource Packs", "Ưu tiên, bật/tắt và quản lý theo profile.")
                Screen.MODPACKS -> Manager("Modpacks", "Import/export và kiểm tra dependency.")
                Screen.MODRINTH -> Modrinth()
                Screen.JAVA -> JavaPage(ram) { ram = it }
                Screen.RENDERER -> Renderer()
                Screen.ACCOUNTS -> Accounts()
                Screen.LOGS -> Logs()
                Screen.SETTINGS -> Manager("Cài đặt", "Giao diện, storage, hiệu năng và launcher core.")
            }
        }
    }
}

fun iconFor(s: Screen) = when(s) {
    Screen.HOME -> Icons.Default.Home
    Screen.INSTANCES -> Icons.Default.Folder
    Screen.MODS -> Icons.Default.Extension
    Screen.SHADERS -> Icons.Default.LightMode
    Screen.PACKS -> Icons.Default.Image
    Screen.MODPACKS -> Icons.Default.Inventory
    Screen.MODRINTH -> Icons.Default.Search
    Screen.JAVA -> Icons.Default.Memory
    Screen.RENDERER -> Icons.Default.Speed
    Screen.ACCOUNTS -> Icons.Default.Person
    Screen.LOGS -> Icons.Default.List
    Screen.SETTINGS -> Icons.Default.Settings
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        if (subtitle.isNotEmpty()) Text(subtitle, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun Home(instance: String, ram: Float, onPlay: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.mika_logo), "MIKA ZS logo",
                    Modifier.size(72.dp))
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("MIKA ZS LAUCHER", style = MaterialTheme.typography.headlineSmall)
                    Text("FCL-based Android Minecraft Launcher")
                }
            }
        }
        item {
            ElevatedCard {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(instance, style = MaterialTheme.typography.titleLarge)
                    Text("Minecraft 1.21.11  •  Fabric")
                    Text("Java 21 ARM64  •  ${ram.toInt()} MB RAM")
                    Button(onClick = onPlay, Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("CHƠI")
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallCard("Mods", "0 lỗi", Icons.Default.Extension, Modifier.weight(1f))
                SmallCard("Java", "ARM64", Icons.Default.Memory, Modifier.weight(1f))
            }
        }
        item {
            ElevatedCard {
                Column(Modifier.padding(18.dp)) {
                    Text("Chẩn đoán nhanh", style = MaterialTheme.typography.titleMedium)
                    Text("Kiểm tra Java • renderer • RAM • mods • crash report")
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {}) { Text("Kiểm tra hệ thống") }
                }
            }
        }
    }
}

@Composable
fun SmallCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null)
            Text(title)
            Text(value, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun Instances(selected: String, select: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Header("Hồ sơ", "Mỗi profile có game directory, Java, RAM, renderer và JVM riêng.") }
        listOf("1.21.11 Fabric", "1.21.11 Vanilla", "1.20.1 Forge").forEach { name ->
            item {
                ElevatedCard(onClick = { select(name) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(name, style = MaterialTheme.typography.titleLarge)
                        Text("Profile riêng • dependency check • backup")
                    }
                }
            }
        }
        item { Button(onClick = {}) { Text("+ Tạo hồ sơ") } }
    }
}

@Composable
fun Manager(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header(title, subtitle)
        ElevatedCard {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quản lý chuyên sâu")
                Button(onClick = {}) { Text("Quét thư mục") }
                OutlinedButton(onClick = {}) { Text("Nhập file") }
                OutlinedButton(onClick = {}) { Text("Kiểm tra tương thích") }
            }
        }
    }
}

@Composable
fun Modrinth() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Modrinth", "Tìm và cài mod theo Minecraft version + loader.")
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("Tìm mod, shader, pack...") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(true, {}, label = { Text("Mods") })
            FilterChip(false, {}, label = { Text("Shaders") })
            FilterChip(false, {}, label = { Text("Modpacks") })
        }
        ElevatedCard { Text("API layer sẵn sàng để nối Modrinth trong launcher core.", Modifier.padding(18.dp)) }
    }
}

@Composable
fun JavaPage(ram: Float, setRam: (Float) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Java / JVM", "Java runtime, RAM và tham số JVM theo profile.")
        ElevatedCard {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Java 21 • ARM64 / aarch64")
                Text("RAM: ${ram.toInt()} MB")
                Slider(ram, setRam, valueRange = 1024f..4096f, steps = 5)
                OutlinedTextField("-Xms512M -Xmx${ram.toInt()}M -XX:+UseG1GC", {},
                    Modifier.fillMaxWidth(), label = { Text("JVM arguments") })
                Button(onClick = {}) { Text("Kiểm tra Java") }
            }
        }
    }
}

@Composable
fun Renderer() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Header("Renderer", "Backend Android tách riêng khỏi UI.")
        listOf("GL4ES", "Zink", "ANGLE", "VirGL", "FCL Renderer Plugin").forEach {
            ElevatedCard(onClick = {}) { Text(it, Modifier.padding(18.dp)) }
        }
    }
}

@Composable
fun Accounts() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Tài khoản", "Microsoft OAuth + token bảo mật bằng Android Keystore.")
        ElevatedCard {
            Column(Modifier.padding(18.dp)) {
                Text("Microsoft Account")
                Button(onClick = {}) { Text("Đăng nhập") }
            }
        }
    }
}

@Composable
fun Logs() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Nhật ký & Crash Analyzer", "latest.log • crash report • JVM stdout/stderr")
        ElevatedCard {
            Column(Modifier.padding(18.dp)) {
                Text("Chưa có log.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {}) { Text("Quét log") }
                OutlinedButton(onClick = {}) { Text("Xuất log") }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
